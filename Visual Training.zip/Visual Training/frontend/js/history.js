document.addEventListener('DOMContentLoaded', function() {
    // 检查登录状态
    if (!localStorage.getItem('token')) {
        window.location.href = 'index.html';
    }
    
    // 事件监听器
    document.getElementById('logout-link').addEventListener('click', function(e) {
        e.preventDefault();
        document.getElementById('logout-modal').style.display = 'block';
    });
    
    // 退出确认
    document.getElementById('confirm-logout').addEventListener('click', function() {
        localStorage.removeItem('token');
        localStorage.removeItem('user_id');
        window.location.href = 'index.html';
    });
    
    document.getElementById('cancel-logout').addEventListener('click', function() {
        document.getElementById('logout-modal').style.display = 'none';
    });
    
    // 加载历史数据
    function loadHistory() {
        // 从localStorage中获取选中的儿童ID
        const childId = localStorage.getItem('selected_child_id');
        
        if (!childId) {
            alert('请先在导航栏中选择儿童');
            return;
        }
        
        const historyList = document.getElementById('history-list');
        historyList.innerHTML = '<p>加载中...</p>';
        
        fetch('http://localhost:5000/api/training/history/' + childId, {
            headers: {
                'Authorization': 'Bearer ' + localStorage.getItem('token')
            }
        })
        .then(response => {
            console.log('Response status:', response.status);
            return response.json();
        })
        .then(data => {
            console.log('History data:', data);
            
            if (data.length === 0) {
                historyList.innerHTML = '<p>暂无训练历史</p>';
            } else {
                // 准备图表数据
                const labels = data.map(session => session.start_time.substring(0, 10));
                const scores = data.map(session => session.total_score || 0);
                const durations = data.map(session => session.duration || 0);
                
                // 生成图表
                generateHistoryChart(labels, scores, durations);
                
                // 显示历史数据列表
                historyList.innerHTML = '';
                data.forEach(session => {
                    const historyItem = document.createElement('div');
                    historyItem.className = 'history-item';
                    const totalScore = session.total_score || 0;
                    historyItem.innerHTML = `
                        <h4>训练时间：${session.start_time}</h4>
                        <p>时长：${session.duration || 0}秒</p>
                        <p>综合评分：${totalScore.toFixed(2)}</p>
                    `;
                    historyList.appendChild(historyItem);
                });
            }
        })
        .catch(error => {
            console.error('Error loading history:', error);
            historyList.innerHTML = '<p>加载历史数据失败</p>';
        });
    }
    
    // 生成历史数据图表
    function generateHistoryChart(labels, scores, durations) {
        const ctx = document.getElementById('history-chart').getContext('2d');
        
        // 销毁旧图表
        if (window.historyChart) {
            window.historyChart.destroy();
        }
        
        // 创建新图表
        window.historyChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: '综合评分',
                    data: scores,
                    borderColor: '#4CAF50',
                    backgroundColor: 'rgba(76, 175, 80, 0.1)',
                    tension: 0.4,
                    fill: true
                }, {
                    label: '训练时长（秒）',
                    data: durations,
                    borderColor: '#2196F3',
                    backgroundColor: 'rgba(33, 150, 243, 0.1)',
                    tension: 0.4,
                    fill: true,
                    yAxisID: 'y1'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: '评分'
                        }
                    },
                    y1: {
                        beginAtZero: true,
                        position: 'right',
                        title: {
                            display: true,
                            text: '时长（秒）'
                        },
                        grid: {
                            drawOnChartArea: false
                        }
                    }
                }
            }
        });
    }
    
    // 点击弹窗外部关闭
    window.onclick = function(event) {
        const modals = document.querySelectorAll('.modal');
        modals.forEach(modal => {
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        });
    };
    
    // 页面加载完成后自动加载历史数据
    window.onload = function() {
        // 延迟一点时间，确保所有DOM元素都已加载
        setTimeout(loadHistory, 500);
    };
});
document.addEventListener('DOMContentLoaded', function () {
    // 检查登录状态
    if (!localStorage.getItem('token')) {
        window.location.href = 'index.html';
    }

    // 加载儿童列表
    loadChildren();

    // 事件监听器
    document.getElementById('add-child-nav').addEventListener('click', function (e) {
        e.preventDefault();
        document.getElementById('add-child-modal').style.display = 'block';
    });

    // 历史数据链接已改为单独页面，不需要点击事件

    document.getElementById('logout-link').addEventListener('click', function (e) {
        e.preventDefault();
        document.getElementById('logout-modal').style.display = 'block';
    });

    // 游戏开始按钮
    document.querySelectorAll('.game-btn').forEach(btn => {
        btn.addEventListener('click', function () {
            const gameType = this.dataset.game;
            startGame(gameType);
        });
    });

    // 弹窗关闭按钮
    document.querySelectorAll('.close').forEach(closeBtn => {
        closeBtn.addEventListener('click', function () {
            this.closest('.modal').style.display = 'none';
        });
    });

    // 退出确认
    document.getElementById('confirm-logout').addEventListener('click', function () {
        localStorage.removeItem('token');
        localStorage.removeItem('user_id');
        window.location.href = 'index.html';
    });

    document.getElementById('cancel-logout').addEventListener('click', function () {
        document.getElementById('logout-modal').style.display = 'none';
    });

    // 添加儿童表单提交
    document.getElementById('add-child-form').addEventListener('submit', function (e) {
        e.preventDefault();

        const name = document.getElementById('child-name').value;
        const age = document.getElementById('child-age').value;

        fetch('http://localhost:5000/api/child/add', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + localStorage.getItem('token')
            },
            body: JSON.stringify({ name, age })
        })
            .then(response => response.json())
            .then(data => {
                if (data.message === 'Child added successfully') {
                    alert('儿童添加成功');
                    document.getElementById('add-child-modal').style.display = 'none';
                    loadChildren();
                } else {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('添加失败，请稍后重试');
            });
    });

    // 保存每日时长设置
    document.getElementById('save-time-btn').addEventListener('click', function () {
        const dailyTime = document.getElementById('daily-time').value;
        localStorage.setItem('daily_time', dailyTime);
        alert('设置保存成功');
    });

    // 加载儿童列表
    function loadChildren() {
        fetch('http://localhost:5000/api/child/list', {
            headers: {
                'Authorization': 'Bearer ' + localStorage.getItem('token')
            }
        })
            .then(response => response.json())
            .then(data => {
                const childSelect = document.getElementById('nav-child-select');
                const selectedChildId = localStorage.getItem('selected_child_id');

                childSelect.innerHTML = '<option value="">-- 选择儿童 --</option>';

                data.forEach(child => {
                    const option = document.createElement('option');
                    option.value = child.id;
                    option.textContent = child.name + ' (' + child.age + '岁)';
                    if (selectedChildId && child.id == selectedChildId) {
                        option.selected = true;
                    }
                    childSelect.appendChild(option);
                });

                // 监听儿童选择变化
                childSelect.addEventListener('change', function () {
                    const selectedId = this.value;
                    if (selectedId) {
                        localStorage.setItem('selected_child_id', selectedId);
                        console.log('Selected child:', selectedId);
                    } else {
                        localStorage.removeItem('selected_child_id');
                    }
                });
            })
            .catch(error => {
                console.error('Error:', error);
            });
    }

    // 历史数据相关功能已移至history.html页面

    // 开始游戏
    function startGame(gameType) {
        // 从localStorage中获取选中的儿童ID
        let childId = localStorage.getItem('selected_child_id');

        // 如果localStorage中没有，从导航栏下拉菜单获取
        if (!childId) {
            childId = document.getElementById('nav-child-select').value;
        }

        if (!childId) {
            alert('请先选择儿童');
            return;
        }

        // 开始训练会话
        fetch('http://localhost:5000/api/training/session/start', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + localStorage.getItem('token')
            },
            body: JSON.stringify({ child_id: childId })
        })
            .then(response => response.json())
            .then(data => {
                if (data.session_id) {
                    // 保存会话ID
                    localStorage.setItem('session_id', data.session_id);
                    // 跳转到游戏页面
                    window.location.href = `game.html?type=${gameType}&child_id=${childId}`;
                } else {
                    alert('开始训练失败');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('开始训练失败');
            });
    }

    // 点击弹窗外部关闭
    window.onclick = function (event) {
        const modals = document.querySelectorAll('.modal');
        modals.forEach(modal => {
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        });
    };
});
document.addEventListener('DOMContentLoaded', function () {
    // 检查登录状态
    if (!localStorage.getItem('token')) {
        window.location.href = 'index.html';
    }

    // 游戏参数
    let gameRunning = false;
    let sessionId = localStorage.getItem('session_id');
    let childId = new URLSearchParams(window.location.search).get('child_id');

    // 游戏元素
    const canvas = document.getElementById('game-canvas');
    const ctx = canvas.getContext('2d');
    const webcam = document.getElementById('webcam');

    // 游戏状态
    let ball = { x: 100, y: 100, radius: 20, speed: 5, dx: 5, dy: 5 };
    let gazePoint = { x: 0, y: 0 };
    let scores = {
        attention: 0,
        stability: 0,
        tracking: 0,
        fatigue: 0,
        distraction: 0
    };

    // 计时器和统计
    let startTime = 0;
    let lastBlinkTime = 0;
    let blinkCount = 0;
    let distractionCount = 0;
    let lastDistractionTime = 0;

    // 护眼保护
    let lastEyeCheckTime = 0;
    const EYE_CHECK_INTERVAL = 5000; // 5秒检查一次

    // 初始化MediaPipe Face Mesh
    let faceMesh;
    let faceMeshLoaded = false;

    function initFaceMesh() {
        console.log('Initializing FaceMesh...');
        if (typeof FaceMesh === 'undefined') {
            console.error('FaceMesh is not loaded');
            updateStatus('FaceMesh加载失败，正在重试...');
            // 尝试重新加载
            setTimeout(initFaceMesh, 3000);
        } else {
            console.log('FaceMesh is available');
            updateStatus('FaceMesh加载成功');
            faceMeshLoaded = true;

            faceMesh = new FaceMesh({
                locateFile: (file) => {
                    return `https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/${file}`;
                }
            });

            faceMesh.setOptions({
                maxNumFaces: 1,
                refineLandmarks: true,
                minDetectionConfidence: 0.5,
                minTrackingConfidence: 0.5
            });
            console.log('FaceMesh initialized with options');

            // 测试FaceMesh是否正常工作
            testFaceMesh();
        }
    }

    // 测试FaceMesh是否正常工作
    function testFaceMesh() {
        if (faceMesh) {
            console.log('Testing FaceMesh...');
            // 这里可以添加一个简单的测试，确保FaceMesh能正常处理图像
            updateStatus('FaceMesh测试成功');
        }
    }

    // 延迟初始化，确保脚本加载完成
    setTimeout(initFaceMesh, 2000);

    // 检查canvas元素
    console.log('Canvas element:', canvas);
    console.log('Canvas width:', canvas.width);
    console.log('Canvas height:', canvas.height);

    // 事件监听器
    console.log('Adding event listeners...');
    const startBtn = document.getElementById('start-btn');
    console.log('Start button element:', startBtn);
    if (startBtn) {
        startBtn.addEventListener('click', startGame);
        console.log('Start button click listener added');
    } else {
        console.error('Start button not found');
    }
    document.getElementById('stop-btn').addEventListener('click', stopGame);
    document.getElementById('back-to-main').addEventListener('click', function () {
        window.location.href = 'main.html';
    });
    document.getElementById('continue-btn').addEventListener('click', function () {
        document.getElementById('eye-protection-modal').style.display = 'none';
        gameRunning = true;
        animate();
    });

    // 更新状态信息
    function updateStatus(message) {
        const statusElement = document.getElementById('status-message');
        if (statusElement) {
            statusElement.textContent = message;
        }
        console.log('Status updated:', message);
    }

    // 开始游戏
    function startGame() {
        console.log('startGame function called');

        // 检查FaceMesh是否加载
        if (!faceMeshLoaded) {
            console.log('FaceMesh not loaded');
            updateStatus('FaceMesh未加载，请等待...');
            alert('FaceMesh正在加载中，请稍后再试');
            return;
        }

        updateStatus('准备开始训练...');

        // 询问用户是否允许访问摄像头
        console.log('Showing camera permission dialog...');
        if (confirm('需要访问您的摄像头以进行视觉训练，是否允许？')) {
            console.log('User granted camera permission');
            updateStatus('正在访问摄像头...');
            // 启动摄像头
            console.log('Accessing webcam...');
            navigator.mediaDevices.getUserMedia({ video: true })
                .then(stream => {
                    console.log('Webcam stream obtained');
                    updateStatus('摄像头已连接...');
                    webcam.srcObject = stream;
                    webcam.onloadedmetadata = () => {
                        console.log('Webcam metadata loaded');
                        // 初始化游戏
                        console.log('Initializing game...');
                        updateStatus('初始化游戏...');
                        initGame();
                        // 开始游戏循环
                        gameRunning = true;
                        startTime = Date.now();
                        document.getElementById('start-btn').disabled = true;
                        document.getElementById('stop-btn').disabled = false;
                        // 显示摄像头已开启的弹窗
                        console.log('Showing camera started alert...');
                        alert('摄像头已成功开启，训练即将开始');
                        updateStatus('训练中...');
                        console.log('Starting animation loop...');
                        animate();
                    };
                })
                .catch(error => {
                    console.error('Error accessing webcam:', error);
                    updateStatus('无法访问摄像头');
                    alert('无法访问摄像头，请检查权限设置');
                });
        } else {
            console.log('User denied camera permission');
            updateStatus('需要摄像头权限才能进行训练');
            alert('需要摄像头权限才能进行训练');
        }
    }

    // 初始化游戏
    function initGame() {
        // 设置canvas尺寸
        canvas.width = canvas.offsetWidth;
        canvas.height = canvas.offsetHeight;

        // 重置游戏状态
        ball = {
            x: canvas.width / 2,
            y: canvas.height / 2,
            radius: 20,
            speed: 5,
            dx: 5,
            dy: 5
        };

        scores = {
            attention: 0,
            stability: 0,
            tracking: 0,
            fatigue: 0,
            distraction: 0
        };

        blinkCount = 0;
        distractionCount = 0;
        lastBlinkTime = Date.now();
        lastDistractionTime = Date.now();

        // 开始面部检测
        if (faceMesh) {
            console.log('Setting up faceMesh onResults');
            faceMesh.onResults(onResults);
            setInterval(() => {
                if (gameRunning && faceMesh) {
                    faceMesh.send({ image: webcam });
                }
            }, 100);
        } else {
            console.error('faceMesh is not initialized');
            updateStatus('面部检测初始化失败');
        }
    }

    // 面部检测结果处理
    function onResults(results) {
        if (!results.multiFaceLandmarks) return;

        const face = results.multiFaceLandmarks[0];
        if (!face) return;

        // 计算视线方向
        const leftEye = face[33];
        const rightEye = face[263];
        const nose = face[1];

        // 估算注视点（简化版）
        gazePoint.x = (leftEye.x + rightEye.x) / 2 * canvas.width;
        gazePoint.y = (leftEye.y + rightEye.y) / 2 * canvas.height;

        // 计算眨眼频率
        const leftEyeTop = face[159];
        const leftEyeBottom = face[145];
        const rightEyeTop = face[386];
        const rightEyeBottom = face[374];

        const leftEyeDistance = Math.sqrt(
            Math.pow(leftEyeTop.x - leftEyeBottom.x, 2) +
            Math.pow(leftEyeTop.y - leftEyeBottom.y, 2)
        );

        const rightEyeDistance = Math.sqrt(
            Math.pow(rightEyeTop.x - rightEyeBottom.x, 2) +
            Math.pow(rightEyeTop.y - rightEyeBottom.y, 2)
        );

        // 检测眨眼
        if (leftEyeDistance < 0.01 && rightEyeDistance < 0.01) {
            const now = Date.now();
            if (now - lastBlinkTime > 500) {
                blinkCount++;
                lastBlinkTime = now;
            }
        }

        // 计算面部距离（简化版）
        const faceWidth = Math.sqrt(
            Math.pow(face[234].x - face[454].x, 2) +
            Math.pow(face[234].y - face[454].y, 2)
        );

        // 计算头部姿态（简化版）
        const eyeLevel = (leftEye.y + rightEye.y) / 2;
        const headTilt = nose.y - eyeLevel;

        // 护眼检查
        const now = Date.now();
        if (now - lastEyeCheckTime > EYE_CHECK_INTERVAL) {
            checkEyeProtection(faceWidth, headTilt);
            lastEyeCheckTime = now;
        }
    }

    // 护眼保护检查
    function checkEyeProtection(faceWidth, headTilt) {
        // 距离检测（面部宽度过小表示距离过远，过大表示距离过近）
        if (faceWidth > 0.5) {
            showEyeProtectionModal('距离屏幕过近，请保持适当距离');
        } else if (faceWidth < 0.2) {
            showEyeProtectionModal('距离屏幕过远，请适当靠近');
        }

        // 坐姿检测（头部俯仰角）
        if (Math.abs(headTilt) > 0.1) {
            showEyeProtectionModal('请保持正确的坐姿，头部不要过度俯仰');
        }

        // 时间检测
        const elapsedTime = (Date.now() - startTime) / 1000 / 60;
        const maxTime = parseInt(localStorage.getItem('daily_time') || 30);
        if (elapsedTime > maxTime) {
            showEyeProtectionModal('训练时间已达到每日上限，请休息');
            stopGame();
        }
    }

    // 显示护眼提醒
    function showEyeProtectionModal(message) {
        document.getElementById('protection-message').textContent = message;
        document.getElementById('eye-protection-modal').style.display = 'block';
        gameRunning = false;
    }

    // 游戏动画循环
    function animate() {
        if (!gameRunning) return;

        // 清空画布
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // 更新小球位置
        updateBall();

        // 绘制小球
        drawBall();

        // 绘制注视点
        drawGazePoint();

        // 计算分数
        calculateScores();

        // 更新UI
        updateUI();

        // 继续动画循环
        requestAnimationFrame(animate);
    }

    // 更新小球位置
    function updateBall() {
        ball.x += ball.dx;
        ball.y += ball.dy;

        // 边界检测
        if (ball.x + ball.radius > canvas.width || ball.x - ball.radius < 0) {
            ball.dx = -ball.dx;
        }
        if (ball.y + ball.radius > canvas.height || ball.y - ball.radius < 0) {
            ball.dy = -ball.dy;
        }
    }

    // 绘制小球
    function drawBall() {
        ctx.beginPath();
        ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
        ctx.fillStyle = '#4CAF50';
        ctx.fill();
        ctx.closePath();
    }

    // 绘制注视点
    function drawGazePoint() {
        ctx.beginPath();
        ctx.arc(gazePoint.x, gazePoint.y, 10, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255, 0, 0, 0.5)';
        ctx.fill();
        ctx.closePath();
    }

    // 计算分数
    function calculateScores() {
        // 注意力方向：计算注视点与屏幕中心的距离
        const centerX = canvas.width / 2;
        const centerY = canvas.height / 2;
        const distanceFromCenter = Math.sqrt(
            Math.pow(gazePoint.x - centerX, 2) +
            Math.pow(gazePoint.y - centerY, 2)
        );
        scores.attention = Math.max(0, 100 - distanceFromCenter / (canvas.width / 2) * 100);

        // 视觉追踪：计算注视点与小球的距离
        const distanceFromBall = Math.sqrt(
            Math.pow(gazePoint.x - ball.x, 2) +
            Math.pow(gazePoint.y - ball.y, 2)
        );
        scores.tracking = Math.max(0, 100 - distanceFromBall / (canvas.width / 2) * 100);

        // 视觉稳定性：简化处理，假设稳定
        scores.stability = 80 + Math.random() * 20;

        // 疲劳状态：基于眨眼频率
        const elapsedTime = (Date.now() - startTime) / 1000 / 60;
        const blinkRate = blinkCount / elapsedTime;
        scores.fatigue = Math.max(0, 100 - blinkRate * 10);

        // 分心检测：如果注视点移出屏幕
        if (gazePoint.x < 0 || gazePoint.x > canvas.width || gazePoint.y < 0 || gazePoint.y > canvas.height) {
            const now = Date.now();
            if (now - lastDistractionTime > 1000) {
                scores.distraction++;
                lastDistractionTime = now;
            }
        }
    }

    // 更新UI
    function updateUI() {
        document.getElementById('attention-score').textContent = Math.round(scores.attention);
        document.getElementById('stability-score').textContent = Math.round(scores.stability);
        document.getElementById('tracking-score').textContent = Math.round(scores.tracking);
        document.getElementById('fatigue-score').textContent = Math.round(scores.fatigue);
        document.getElementById('distraction-count').textContent = scores.distraction;
    }

    // 停止游戏
    function stopGame() {
        gameRunning = false;

        // 计算总得分
        const totalScore = (scores.attention + scores.stability + scores.tracking + scores.fatigue) / 4;

        // 显示结果
        document.getElementById('total-score').textContent = Math.round(totalScore);
        document.getElementById('final-attention').textContent = Math.round(scores.attention);
        document.getElementById('final-stability').textContent = Math.round(scores.stability);
        document.getElementById('final-tracking').textContent = Math.round(scores.tracking);
        document.getElementById('final-fatigue').textContent = Math.round(scores.fatigue);

        // 保存训练数据
        saveTrainingData(totalScore);

        // 显示结果弹窗
        document.getElementById('result-modal').style.display = 'block';

        // 重置按钮状态
        document.getElementById('start-btn').disabled = false;
        document.getElementById('stop-btn').disabled = true;
    }

    // 保存训练数据
    function saveTrainingData(totalScore) {
        const trainingData = {
            session_id: sessionId,
            attention_direction: scores.attention,
            visual_stability: scores.stability,
            visual_tracking: scores.tracking,
            fatigue_level: scores.fatigue,
            distraction_count: scores.distraction,
            blink_frequency: blinkCount / ((Date.now() - startTime) / 1000 / 60),
            screen_time_ratio: 1.0 // 简化处理
        };

        // 发送数据到后端
        fetch('http://localhost:5000/api/training/data/add', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + localStorage.getItem('token')
            },
            body: JSON.stringify(trainingData)
        })
            .then(response => response.json())
            .then(data => {
                console.log('Training data saved:', data);

                // 结束训练会话
                fetch('http://localhost:5000/api/training/session/end/' + sessionId, {
                    method: 'PUT',
                    headers: {
                        'Authorization': 'Bearer ' + localStorage.getItem('token')
                    }
                })
                    .then(response => response.json())
                    .then(data => {
                        console.log('Session ended:', data);
                    })
                    .catch(error => {
                        console.error('Error ending session:', error);
                    });
            })
            .catch(error => {
                console.error('Error saving training data:', error);
            });
    }

    // 点击弹窗外部关闭
    window.onclick = function (event) {
        const modals = document.querySelectorAll('.modal');
        modals.forEach(modal => {
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        });
    };
});
from flask import Blueprint, request, jsonify
from datetime import datetime
from jwt.api_jwt import decode
from config.config import Config
from extensions import db
from models.training_session import TrainingSession
from models.training_data import TrainingData

training_bp = Blueprint('training', __name__)

def get_user_id_from_token(token):
    try:
        payload = decode(token, Config.SECRET_KEY, algorithms=['HS256'])
        return payload['user_id']
    except:
        return None

@training_bp.route('/session/start', methods=['POST'])
def start_session():
    token = request.headers.get('Authorization')
    if not token:
        return jsonify({'message': 'Missing token'}), 401
    
    user_id = get_user_id_from_token(token.split(' ')[1])
    if not user_id:
        return jsonify({'message': 'Invalid token'}), 401
    
    data = request.get_json()
    child_id = data.get('child_id')
    
    new_session = TrainingSession(child_id=child_id)
    db.session.add(new_session)
    db.session.commit()
    
    return jsonify({'message': 'Session started successfully', 'session_id': new_session.id}), 201

@training_bp.route('/session/end/<int:session_id>', methods=['PUT'])
def end_session(session_id):
    token = request.headers.get('Authorization')
    if not token:
        return jsonify({'message': 'Missing token'}), 401
    
    user_id = get_user_id_from_token(token.split(' ')[1])
    if not user_id:
        return jsonify({'message': 'Invalid token'}), 401
    
    session = TrainingSession.query.get(session_id)
    if not session:
        return jsonify({'message': 'Session not found'}), 404
    
    session.end_time = datetime.utcnow()
    session.duration = int((session.end_time - session.start_time).total_seconds())
    
    # 计算综合评分
    training_data = TrainingData.query.filter_by(session_id=session_id).all()
    if training_data:
        total_score = 0
        count = 0
        for data in training_data:
            total_score += (data.attention_direction or 0) + (data.visual_stability or 0) + (data.visual_tracking or 0) + (data.fatigue_level or 0)
            count += 4
        session.total_score = total_score / count if count > 0 else 0
    
    db.session.commit()
    
    return jsonify({'message': 'Session ended successfully'}), 200

@training_bp.route('/data/add', methods=['POST'])
def add_training_data():
    token = request.headers.get('Authorization')
    if not token:
        return jsonify({'message': 'Missing token'}), 401
    
    user_id = get_user_id_from_token(token.split(' ')[1])
    if not user_id:
        return jsonify({'message': 'Invalid token'}), 401
    
    data = request.get_json()
    session_id = data.get('session_id')
    attention_direction = data.get('attention_direction')
    visual_stability = data.get('visual_stability')
    visual_tracking = data.get('visual_tracking')
    fatigue_level = data.get('fatigue_level')
    distraction_count = data.get('distraction_count')
    blink_frequency = data.get('blink_frequency')
    screen_time_ratio = data.get('screen_time_ratio')
    
    new_data = TrainingData(
        session_id=session_id,
        attention_direction=attention_direction,
        visual_stability=visual_stability,
        visual_tracking=visual_tracking,
        fatigue_level=fatigue_level,
        distraction_count=distraction_count,
        blink_frequency=blink_frequency,
        screen_time_ratio=screen_time_ratio
    )
    db.session.add(new_data)
    db.session.commit()
    
    return jsonify({'message': 'Training data added successfully'}), 201

@training_bp.route('/history/<int:child_id>', methods=['GET'])
def get_training_history(child_id):
    token = request.headers.get('Authorization')
    if not token:
        return jsonify({'message': 'Missing token'}), 401
    
    user_id = get_user_id_from_token(token.split(' ')[1])
    if not user_id:
        return jsonify({'message': 'Invalid token'}), 401
    
    sessions = TrainingSession.query.filter_by(child_id=child_id).order_by(TrainingSession.start_time.desc()).all()
    history = []
    for session in sessions:
        session_data = {
            'session_id': session.id,
            'start_time': session.start_time.strftime('%Y-%m-%d %H:%M:%S'),
            'end_time': session.end_time.strftime('%Y-%m-%d %H:%M:%S') if session.end_time else None,
            'duration': session.duration,
            'total_score': session.total_score
        }
        history.append(session_data)
    
    return jsonify(history), 200


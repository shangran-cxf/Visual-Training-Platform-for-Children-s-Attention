from flask import Blueprint, request, jsonify
from jwt.api_jwt import decode
from config.config import Config
from extensions import db
from models.child import Child

child_bp = Blueprint('child', __name__)

def get_user_id_from_token(token):
    try:
        payload = decode(token, Config.SECRET_KEY, algorithms=['HS256'])
        return payload['user_id']
    except:
        return None

@child_bp.route('/add', methods=['POST'])
def add_child():
    token = request.headers.get('Authorization')
    if not token:
        return jsonify({'message': 'Missing token'}), 401
    
    user_id = get_user_id_from_token(token.split(' ')[1])
    if not user_id:
        return jsonify({'message': 'Invalid token'}), 401
    
    data = request.get_json()
    name = data.get('name')
    age = data.get('age')
    
    new_child = Child(user_id=user_id, name=name, age=age)
    db.session.add(new_child)
    db.session.commit()
    
    return jsonify({'message': 'Child added successfully', 'child_id': new_child.id}), 201

@child_bp.route('/list', methods=['GET'])
def get_children():
    token = request.headers.get('Authorization')
    if not token:
        return jsonify({'message': 'Missing token'}), 401
    
    user_id = get_user_id_from_token(token.split(' ')[1])
    if not user_id:
        return jsonify({'message': 'Invalid token'}), 401
    
    children = Child.query.filter_by(user_id=user_id).all()
    children_list = [{'id': child.id, 'name': child.name, 'age': child.age} for child in children]
    
    return jsonify(children_list), 200

@child_bp.route('/update/<int:child_id>', methods=['PUT'])
def update_child(child_id):
    token = request.headers.get('Authorization')
    if not token:
        return jsonify({'message': 'Missing token'}), 401
    
    user_id = get_user_id_from_token(token.split(' ')[1])
    if not user_id:
        return jsonify({'message': 'Invalid token'}), 401
    
    child = Child.query.filter_by(id=child_id, user_id=user_id).first()
    if not child:
        return jsonify({'message': 'Child not found'}), 404
    
    data = request.get_json()
    if 'name' in data:
        child.name = data['name']
    if 'age' in data:
        child.age = data['age']
    
    db.session.commit()
    
    return jsonify({'message': 'Child updated successfully'}), 200

@child_bp.route('/delete/<int:child_id>', methods=['DELETE'])
def delete_child(child_id):
    token = request.headers.get('Authorization')
    if not token:
        return jsonify({'message': 'Missing token'}), 401
    
    user_id = get_user_id_from_token(token.split(' ')[1])
    if not user_id:
        return jsonify({'message': 'Invalid token'}), 401
    
    child = Child.query.filter_by(id=child_id, user_id=user_id).first()
    if not child:
        return jsonify({'message': 'Child not found'}), 404
    
    db.session.delete(child)
    db.session.commit()
    
    return jsonify({'message': 'Child deleted successfully'}), 200


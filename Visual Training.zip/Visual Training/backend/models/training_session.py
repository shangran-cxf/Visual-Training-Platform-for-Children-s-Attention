from extensions import db
from datetime import datetime

class TrainingSession(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    child_id = db.Column(db.Integer, db.ForeignKey('child.id'), nullable=False)
    start_time = db.Column(db.DateTime, default=datetime.utcnow)
    end_time = db.Column(db.DateTime)
    duration = db.Column(db.Integer)  # 训练时长（秒）
    total_score = db.Column(db.Float)  # 综合评分
    
    # 关系
    training_data = db.relationship('TrainingData', backref='session', lazy=True)
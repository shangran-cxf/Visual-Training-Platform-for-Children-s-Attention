from extensions import db
from datetime import datetime

class TrainingData(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.Integer, db.ForeignKey('training_session.id'), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    attention_direction = db.Column(db.Float)  # 注意力方向评分
    visual_stability = db.Column(db.Float)  # 视觉专注稳定性评分
    visual_tracking = db.Column(db.Float)  # 视觉追踪能力评分
    fatigue_level = db.Column(db.Float)  # 疲劳状态评分
    distraction_count = db.Column(db.Integer)  # 分心次数
    blink_frequency = db.Column(db.Float)  # 眨眼频率
    screen_time_ratio = db.Column(db.Float)  # 注视屏幕时长占比
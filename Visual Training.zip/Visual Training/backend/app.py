from flask import Flask, jsonify, request
from flask_cors import CORS
from config.config import Config

# 初始化app
app = Flask(__name__)
app.config.from_object(Config)
CORS(app)

# 导入扩展
from extensions import db
db.init_app(app)

# 导入模型
from models.user import User
from models.child import Child
from models.training_session import TrainingSession
from models.training_data import TrainingData

# 导入API蓝图
from api.auth import auth_bp
from api.child import child_bp
from api.training import training_bp

# 注册蓝图
app.register_blueprint(auth_bp, url_prefix='/api/auth')
app.register_blueprint(child_bp, url_prefix='/api/child')
app.register_blueprint(training_bp, url_prefix='/api/training')

if __name__ == '__main__':
    app.run(debug=True)
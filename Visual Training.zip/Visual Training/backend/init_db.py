from app import app, db
from models import User, Child, TrainingSession, TrainingData

with app.app_context():
    print("Creating database tables...")
    db.create_all()
    print("Database tables created successfully!")
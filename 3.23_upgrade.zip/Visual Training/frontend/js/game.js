document.addEventListener('DOMContentLoaded', function () {
    if (!localStorage.getItem('token')) {
        window.location.href = 'index.html';
    }

    let gameRunning = false;
    let sessionId = localStorage.getItem('session_id');
    let childId = new URLSearchParams(window.location.search).get('child_id');

    const canvas = document.getElementById('game-canvas');
    const ctx = canvas.getContext('2d');
    const webcam = document.getElementById('webcam');

    let ball = { x: 100, y: 100, radius: 20, speed: 5, dx: 5, dy: 5 };
    let gazePoint = { x: 0, y: 0 };
    let scores = {
        attention: 0,
        stability: 0,
        tracking: 0,
        fatigue: 0,
        distraction: 0
    };

    let startTime = 0;
    let lastBlinkTime = 0;
    let blinkCount = 0;
    let distractionCount = 0;
    let lastDistractionTime = 0;

    let lastEyeCheckTime = 0;
    const EYE_CHECK_INTERVAL = 5000;

    let faceMesh;
    let faceMeshLoaded = false;
    let librariesLoaded = false;

    async function loadDependencies() {
        updateStatus('正在加载依赖库...');
        
        const scripts = [
            'https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/face_mesh.min.js'
        ];

        for (const src of scripts) {
            await new Promise((resolve, reject) => {
                if (document.querySelector(`script[src="${src}"]`)) {
                    resolve();
                    return;
                }
                const script = document.createElement('script');
                script.src = src;
                script.onload = resolve;
                script.onerror = reject;
                document.head.appendChild(script);
            });
        }

        librariesLoaded = true;
        updateStatus('依赖库加载完成，点击开始训练');
    }

    loadDependencies();

    function initFaceMesh() {
        console.log('Initializing FaceMesh...');
        if (typeof FaceMesh === 'undefined') {
            console.error('FaceMesh is not loaded');
            updateStatus('FaceMesh加载失败，正在重试...');
            setTimeout(initFaceMesh, 3000);
        } else {
            console.log('FaceMesh is available');
            updateStatus('FaceMesh加载成功');
            faceMeshLoaded = true;

            faceMesh = new FaceMesh({
                locateFile: (file) => {
                    return `https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/${file}`;
                }
            });

            faceMesh.setOptions({
                maxNumFaces: 1,
                refineLandmarks: true,
                minDetectionConfidence: 0.5,
                minTrackingConfidence: 0.5
            });
            console.log('FaceMesh initialized with options');
            updateStatus('准备就绪，点击开始训练');
        }
    }

    console.log('Canvas element:', canvas);

    const startBtn = document.getElementById('start-btn');
    if (startBtn) {
        startBtn.addEventListener('click', startGame);
    }
    document.getElementById('stop-btn').addEventListener('click', stopGame);
    document.getElementById('back-to-main').addEventListener('click', function () {
        window.location.href = 'main.html';
    });
    document.getElementById('continue-btn').addEventListener('click', function () {
        document.getElementById('eye-protection-modal').style.display = 'none';
        gameRunning = true;
        animate();
    });

    function updateStatus(message) {
        const statusElement = document.getElementById('status-message');
        if (statusElement) {
            statusElement.textContent = message;
        }
        console.log('Status updated:', message);
    }

    async function startGame() {
        console.log('startGame function called');

        if (!librariesLoaded) {
            updateStatus('依赖库正在加载中，请稍候...');
            alert('依赖库正在加载中，请稍后再试');
            return;
        }

        if (!faceMeshLoaded) {
            updateStatus('正在初始化FaceMesh...');
            initFaceMesh();
            if (!faceMeshLoaded) {
                alert('FaceMesh正在初始化，请稍后再试');
                return;
            }
        }

        updateStatus('准备开始训练...');

        if (confirm('需要访问您的摄像头以进行视觉训练，是否允许？')) {
            updateStatus('正在访问摄像头...');
            navigator.mediaDevices.getUserMedia({ video: true })
                .then(stream => {
                    updateStatus('摄像头已连接...');
                    webcam.srcObject = stream;
                    webcam.onloadedmetadata = () => {
                        updateStatus('初始化游戏...');
                        initGame();
                        gameRunning = true;
                        startTime = Date.now();
                        document.getElementById('start-btn').disabled = true;
                        document.getElementById('stop-btn').disabled = false;
                        alert('摄像头已成功开启，训练即将开始');
                        updateStatus('训练中...');
                        animate();
                    };
                })
                .catch(error => {
                    console.error('Error accessing webcam:', error);
                    updateStatus('无法访问摄像头');
                    alert('无法访问摄像头，请检查权限设置');
                });
        } else {
            updateStatus('需要摄像头权限才能进行训练');
            alert('需要摄像头权限才能进行训练');
        }
    }

    function initGame() {
        canvas.width = canvas.offsetWidth;
        canvas.height = canvas.offsetHeight;

        ball = {
            x: canvas.width / 2,
            y: canvas.height / 2,
            radius: 20,
            speed: 5,
            dx: 5,
            dy: 5
        };

        scores = {
            attention: 0,
            stability: 0,
            tracking: 0,
            fatigue: 0,
            distraction: 0
        };

        blinkCount = 0;
        distractionCount = 0;
        lastBlinkTime = Date.now();
        lastDistractionTime = Date.now();

        if (faceMesh) {
            console.log('Setting up faceMesh onResults');
            faceMesh.onResults(onResults);
            setInterval(() => {
                if (gameRunning && faceMesh) {
                    faceMesh.send({ image: webcam });
                }
            }, 100);
        } else {
            console.error('faceMesh is not initialized');
            updateStatus('面部检测初始化失败');
        }
    }

    function onResults(results) {
        if (!results.multiFaceLandmarks) return;

        const face = results.multiFaceLandmarks[0];
        if (!face) return;

        const leftEye = face[33];
        const rightEye = face[263];
        const nose = face[1];

        gazePoint.x = (leftEye.x + rightEye.x) / 2 * canvas.width;
        gazePoint.y = (leftEye.y + rightEye.y) / 2 * canvas.height;

        const leftEyeTop = face[159];
        const leftEyeBottom = face[145];
        const rightEyeTop = face[386];
        const rightEyeBottom = face[374];

        const leftEyeDistance = Math.sqrt(
            Math.pow(leftEyeTop.x - leftEyeBottom.x, 2) +
            Math.pow(leftEyeTop.y - leftEyeBottom.y, 2)
        );

        const rightEyeDistance = Math.sqrt(
            Math.pow(rightEyeTop.x - rightEyeBottom.x, 2) +
            Math.pow(rightEyeTop.y - rightEyeBottom.y, 2)
        );

        if (leftEyeDistance < 0.01 && rightEyeDistance < 0.01) {
            const now = Date.now();
            if (now - lastBlinkTime > 500) {
                blinkCount++;
                lastBlinkTime = now;
            }
        }

        const faceWidth = Math.sqrt(
            Math.pow(face[234].x - face[454].x, 2) +
            Math.pow(face[234].y - face[454].y, 2)
        );

        const eyeLevel = (leftEye.y + rightEye.y) / 2;
        const headTilt = nose.y - eyeLevel;

        const now = Date.now();
        if (now - lastEyeCheckTime > EYE_CHECK_INTERVAL) {
            checkEyeProtection(faceWidth, headTilt);
            lastEyeCheckTime = now;
        }
    }

    function checkEyeProtection(faceWidth, headTilt) {
        if (faceWidth > 0.5) {
            showEyeProtectionModal('距离屏幕过近，请保持适当距离');
        } else if (faceWidth < 0.2) {
            showEyeProtectionModal('距离屏幕过远，请适当靠近');
        }

        if (Math.abs(headTilt) > 0.1) {
            showEyeProtectionModal('请保持正确的坐姿，头部不要过度俯仰');
        }

        const elapsedTime = (Date.now() - startTime) / 1000 / 60;
        const maxTime = parseInt(localStorage.getItem('daily_time') || 30);
        if (elapsedTime > maxTime) {
            showEyeProtectionModal('训练时间已达到每日上限，请休息');
            stopGame();
        }
    }

    function showEyeProtectionModal(message) {
        document.getElementById('protection-message').textContent = message;
        document.getElementById('eye-protection-modal').style.display = 'block';
        gameRunning = false;
    }

    function animate() {
        if (!gameRunning) return;

        ctx.clearRect(0, 0, canvas.width, canvas.height);

        updateBall();
        drawBall();
        drawGazePoint();
        calculateScores();
        updateUI();

        requestAnimationFrame(animate);
    }

    function updateBall() {
        ball.x += ball.dx;
        ball.y += ball.dy;

        if (ball.x + ball.radius > canvas.width || ball.x - ball.radius < 0) {
            ball.dx = -ball.dx;
        }
        if (ball.y + ball.radius > canvas.height || ball.y - ball.radius < 0) {
            ball.dy = -ball.dy;
        }
    }

    function drawBall() {
        ctx.beginPath();
        ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
        ctx.fillStyle = '#4CAF50';
        ctx.fill();
        ctx.closePath();
    }

    function drawGazePoint() {
        ctx.beginPath();
        ctx.arc(gazePoint.x, gazePoint.y, 10, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255, 0, 0, 0.5)';
        ctx.fill();
        ctx.closePath();
    }

    function calculateScores() {
        const centerX = canvas.width / 2;
        const centerY = canvas.height / 2;
        const distanceFromCenter = Math.sqrt(
            Math.pow(gazePoint.x - centerX, 2) +
            Math.pow(gazePoint.y - centerY, 2)
        );
        scores.attention = Math.max(0, 100 - distanceFromCenter / (canvas.width / 2) * 100);

        const distanceFromBall = Math.sqrt(
            Math.pow(gazePoint.x - ball.x, 2) +
            Math.pow(gazePoint.y - ball.y, 2)
        );
        scores.tracking = Math.max(0, 100 - distanceFromBall / (canvas.width / 2) * 100);

        scores.stability = 80 + Math.random() * 20;

        const elapsedTime = (Date.now() - startTime) / 1000 / 60;
        const blinkRate = blinkCount / elapsedTime;
        scores.fatigue = Math.max(0, 100 - blinkRate * 10);

        if (gazePoint.x < 0 || gazePoint.x > canvas.width || gazePoint.y < 0 || gazePoint.y > canvas.height) {
            const now = Date.now();
            if (now - lastDistractionTime > 1000) {
                scores.distraction++;
                lastDistractionTime = now;
            }
        }
    }

    function updateUI() {
        document.getElementById('attention-score').textContent = Math.round(scores.attention);
        document.getElementById('stability-score').textContent = Math.round(scores.stability);
        document.getElementById('tracking-score').textContent = Math.round(scores.tracking);
        document.getElementById('fatigue-score').textContent = Math.round(scores.fatigue);
        document.getElementById('distraction-count').textContent = scores.distraction;
    }

    function stopGame() {
        gameRunning = false;

        const totalScore = (scores.attention + scores.stability + scores.tracking + scores.fatigue) / 4;

        document.getElementById('total-score').textContent = Math.round(totalScore);
        document.getElementById('final-attention').textContent = Math.round(scores.attention);
        document.getElementById('final-stability').textContent = Math.round(scores.stability);
        document.getElementById('final-tracking').textContent = Math.round(scores.tracking);
        document.getElementById('final-fatigue').textContent = Math.round(scores.fatigue);

        saveTrainingData(totalScore);

        document.getElementById('result-modal').style.display = 'block';

        document.getElementById('start-btn').disabled = false;
        document.getElementById('stop-btn').disabled = true;
    }

    function saveTrainingData(totalScore) {
        const trainingData = {
            session_id: sessionId,
            attention_direction: scores.attention,
            visual_stability: scores.stability,
            visual_tracking: scores.tracking,
            fatigue_level: scores.fatigue,
            distraction_count: scores.distraction,
            blink_frequency: blinkCount / ((Date.now() - startTime) / 1000 / 60),
            screen_time_ratio: 1.0
        };

        fetch('http://localhost:5000/api/training/data/add', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + localStorage.getItem('token')
            },
            body: JSON.stringify(trainingData)
        })
            .then(response => response.json())
            .then(data => {
                console.log('Training data saved:', data);

                fetch('http://localhost:5000/api/training/session/end/' + sessionId, {
                    method: 'PUT',
                    headers: {
                        'Authorization': 'Bearer ' + localStorage.getItem('token')
                    }
                })
                    .then(response => response.json())
                    .then(data => {
                        console.log('Session ended:', data);
                    })
                    .catch(error => {
                        console.error('Error ending session:', error);
                    });
            })
            .catch(error => {
                console.error('Error saving training data:', error);
            });
    }

    window.onclick = function (event) {
        const modals = document.querySelectorAll('.modal');
        modals.forEach(modal => {
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        });
    };
});

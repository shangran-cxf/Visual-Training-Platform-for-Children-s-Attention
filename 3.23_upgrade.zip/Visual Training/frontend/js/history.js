document.addEventListener('DOMContentLoaded', function() {
    if (!localStorage.getItem('token')) {
        window.location.href = 'index.html';
    }
    
    let chartLoaded = false;
    
    async function loadChartJS() {
        if (chartLoaded) return true;
        
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = 'https://cdn.jsdelivr.net/npm/chart.js';
            script.onload = () => {
                chartLoaded = true;
                resolve(true);
            };
            script.onerror = reject;
            document.head.appendChild(script);
        });
    }
    
    document.getElementById('logout-link').addEventListener('click', function(e) {
        e.preventDefault();
        document.getElementById('logout-modal').style.display = 'block';
    });
    
    document.getElementById('confirm-logout').addEventListener('click', function() {
        localStorage.removeItem('token');
        localStorage.removeItem('user_id');
        window.location.href = 'index.html';
    });
    
    document.getElementById('cancel-logout').addEventListener('click', function() {
        document.getElementById('logout-modal').style.display = 'none';
    });
    
    async function loadHistory() {
        const childId = localStorage.getItem('selected_child_id');
        
        if (!childId) {
            alert('请先在导航栏中选择儿童');
            return;
        }
        
        const historyList = document.getElementById('history-list');
        historyList.innerHTML = '<p>加载中...</p>';
        
        fetch('http://localhost:5000/api/training/history/' + childId, {
            headers: {
                'Authorization': 'Bearer ' + localStorage.getItem('token')
            }
        })
        .then(response => {
            console.log('Response status:', response.status);
            return response.json();
        })
        .then(async data => {
            console.log('History data:', data);
            
            if (data.length === 0) {
                historyList.innerHTML = '<p>暂无训练历史</p>';
            } else {
                const labels = data.map(session => session.start_time.substring(0, 10));
                const scores = data.map(session => session.total_score || 0);
                const durations = data.map(session => session.duration || 0);
                
                await loadChartJS();
                generateHistoryChart(labels, scores, durations);
                
                historyList.innerHTML = '';
                data.forEach(session => {
                    const historyItem = document.createElement('div');
                    historyItem.className = 'history-item';
                    const totalScore = session.total_score || 0;
                    historyItem.innerHTML = `
                        <h4>训练时间：${session.start_time}</h4>
                        <p>时长：${session.duration || 0}秒</p>
                        <p>综合评分：${totalScore.toFixed(2)}</p>
                    `;
                    historyList.appendChild(historyItem);
                });
            }
        })
        .catch(error => {
            console.error('Error loading history:', error);
            historyList.innerHTML = '<p>加载历史数据失败</p>';
        });
    }
    
    function generateHistoryChart(labels, scores, durations) {
        const ctx = document.getElementById('history-chart').getContext('2d');
        
        if (window.historyChart) {
            window.historyChart.destroy();
        }
        
        window.historyChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: '综合评分',
                    data: scores,
                    borderColor: '#4CAF50',
                    backgroundColor: 'rgba(76, 175, 80, 0.1)',
                    tension: 0.4,
                    fill: true
                }, {
                    label: '训练时长（秒）',
                    data: durations,
                    borderColor: '#2196F3',
                    backgroundColor: 'rgba(33, 150, 243, 0.1)',
                    tension: 0.4,
                    fill: true,
                    yAxisID: 'y1'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: '评分'
                        }
                    },
                    y1: {
                        beginAtZero: true,
                        position: 'right',
                        title: {
                            display: true,
                            text: '时长（秒）'
                        },
                        grid: {
                            drawOnChartArea: false
                        }
                    }
                }
            }
        });
    }
    
    window.onclick = function(event) {
        const modals = document.querySelectorAll('.modal');
        modals.forEach(modal => {
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        });
    };
    
    window.onload = function() {
        setTimeout(loadHistory, 300);
    };
});
